import re
import sys
import keyboard

def interpret(code, variables=None):
    if variables is None:
        variables = {}
        
    lines = code.split('\n')
    i = 0
    while i < len(lines):
        # Sprawdzanie, czy klawisz ESC został naciśnięty
        if keyboard.is_pressed('esc'):
            print("Exiting program with ESC.")
            sys.exit()
        
        line = lines[i].strip()
        if not line or line.startswith('#'):  # Komentarze
            i += 1
            continue
        
        # Deklaracja zmiennej
        if ' = ' in line:
            if line.startswith('int '):
                var, val = line[4:].split(' = ')
                variables[var.strip()] = int(val.strip().strip(';'))
            elif line.startswith('var '):
                var, val = line[4:].split(' = ')
                variables[var.strip()] = val.strip().strip('";')
        
        # Drukowanie zmiennej lub ciągu znaków
        elif line.startswith('print'):
            var = re.findall(r'\((.*?)\)', line)[0]
            if var.strip().startswith('"') and var.strip().endswith('"'):
                print(var.strip().strip('"'))
            elif var.strip() in variables:
                print(variables[var.strip()])
            else:
                print(f'Variable {var.strip()} not defined')
        
        # Warunki
        elif line.startswith('if'):
            condition = re.findall(r'\((.*?)\)', line)[0]
            var, op, val = re.split(r'([><=]+)', condition)
            if eval(f'{variables.get(var.strip(), 0)} {op} {val.strip()}'):
                print("Condition met")
        
        # Pętla while
        elif line.startswith('while'):
            condition = re.findall(r'\((.*?)\)', line)[0]
            var, op, val = re.split(r'([><=]+)', condition)
            start_line = i
            while eval(f'{variables.get(var.strip(), 0)} {op} {val.strip()}'):
                i += 1
                while i < len(lines) and not lines[i].strip().startswith('}'):
                    interpret('\n'.join(lines[start_line+1:i+1]), variables)
                i = start_line
        
        # Komenda loop
        elif line.startswith('loop'):
            count = int(re.findall(r'\((.*?)\)', line)[0])
            i += 1
            loop_code = lines[i].strip()
            for _ in range(count):
                interpret(loop_code, variables)
        
        # Komenda exit
        elif line.startswith('exit'):
            print("Exiting program.")
            sys.exit()
        
        i += 1

if __name__ == '__main__':
    with open('examples/example.jt', 'r') as file:
        code = file.read()
    interpret(code)
