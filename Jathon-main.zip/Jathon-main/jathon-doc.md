Po Polsku/In Polsih
# Jathon - Dokumentacja Użytkownika

## 1. Wprowadzenie
Jathon jest nowym językiem programowania, który został stworzony, aby połączyć zalety Pythona z unikalnymi możliwościami dla programistów. Jathon jest łatwy do nauki i oferuje nowoczesne funkcje, które sprawiają, że programowanie jest przyjemniejsze i bardziej efektywne.

### Główne cechy i zalety
- Łatwa składnia
- Silne typowanie danych
- Wsparcie dla operacji matematycznych i logicznych
- Nowoczesne funkcje kontrolne
- Wsparcie dla pracy z plikami

## 2. Instalacja
### Wymagania systemowe
- System operacyjny: Windows, macOS, Linux
- Python 3.6 lub nowszy

### Kroki instalacji
1. Pobierz i zainstaluj Python 3.6 lub nowszy.
2. Pobierz i zainstaluj Jathon z oficjalnej strony [jathon.org](https://www.jathon.org).
3. Upewnij się, że Jathon jest zainstalowany, uruchamiając `jathon --version` w terminalu.

## 3. Podstawy Jathon
### Składnia
```plaintext
# To jest komentarz w Jathon
int a = 10;
var b = "Hello, world!";
print(a + b);
Zmienne i typy danych
Jathon obsługuje różne typy danych, takie jak liczby całkowite, liczby zmiennoprzecinkowe, ciągi znaków i listy.

Operatory
Aritmetyczne: +, -, *, /, %

Porównawcze: ==, !=, >, <, >=, <=

Logiczne: and, or, not

4. Struktury Kontrolne
Instrukcje warunkowe
plaintext
if (a > b) {
    print("a jest większe niż b");
} elif (a == b) {
    print("a jest równe b");
} else {
    print("a jest mniejsze niż b");
}
Pętle
Pętla for
plaintext
for (int i = 0; i < 10; i++) {
    print(i);
}
Pętla while
plaintext
while (a < b) {
    a += 1;
    print(a);
}
5. Funkcje
Definiowanie i wywoływanie funkcji
plaintext
def add(a, b):
    return a + b;

var result = add(5, 3);
print(result);
Argumenty i wartości zwracane
Funkcje w Jathon mogą przyjmować argumenty i zwracać wartości za pomocą return.

6. Praca z Plikami
Odczyt i zapis plików
plaintext
# Otwieranie pliku do odczytu
var file = open("file.txt", "r");
var content = file.read();
file.close();

# Otwieranie pliku do zapisu
var file = open("file.txt", "w");
file.write("Hello, world!");
file.close();
Obsługa błędów
plaintext
try:
    var file = open("file.txt", "r");
    var content = file.read();
    file.close();
except IOError:
    print("Błąd: nie można otworzyć pliku.");
7. Przykłady Kodów
Przykłady podstawowych programów w Jathon
plaintext
# Hello, world! w Jathon
print("Hello, world!");

# Kalkulator prosty
def calculator(a, b, operation):
    if operation == "add":
        return a + b;
    elif operation == "subtract":
        return a - b;
    elif operation == "multiply":
        return a * b;
    elif operation == "divide":
        return a / b;

var result = calculator(10, 5, "add");
print(result);
Projekty demonstracyjne
Gra Tic-Tac-Toe

Kalkulator naukowy

Prosty edytor tekstu

8. Dokumentacja Modułów
gen_world.jt
inv.jt
health.jt
craf.jt
fight.jt
9. Często Zadawane Pytania (FAQ)
Odpowiedzi na najczęściej zadawane pytania
10. Zasoby
strona : 
 Po Angielsku/In English
 Jathon - User Documentation
1. Introduction
Jathon is a new programming language designed to combine the benefits of Python with unique features for developers. Jathon is easy to learn and offers modern features that make programming more enjoyable and efficient.

Main features and benefits
Easy syntax

Strong typing

Support for mathematical and logical operations

Modern control structures

File handling support

2. Installation
System requirements
Operating system: Windows, macOS, Linux

Python 3.6 or later

Installation steps
Download and install Python 3.6 or later.

Download and install Jathon from the official website jathon.org.

Ensure that Jathon is installed by running jathon --version in the terminal.

3. Basics of Jathon
Syntax
plaintext
# This is a comment in Jathon
int a = 10;
var b = "Hello, world!";
print(a + b);
Variables and data types
Jathon supports various data types, such as integers, floating-point numbers, strings, and lists.

Operators
Arithmetic: +, -, *, /, %

Comparison: ==, !=, >, <, >=, <=

Logical: and, or, not